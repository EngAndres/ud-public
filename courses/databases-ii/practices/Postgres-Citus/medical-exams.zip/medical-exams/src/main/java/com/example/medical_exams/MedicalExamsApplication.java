package com.example.medical_exams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalExamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalExamsApplication.class, args);
	}

}
